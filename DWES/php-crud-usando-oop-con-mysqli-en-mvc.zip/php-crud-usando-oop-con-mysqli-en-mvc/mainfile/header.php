<html>
<head>
<title>PHP CRUD usando OOP con MySQLi en MVC</title>
<link href="mainfile/css/style.css" type="text/css" rel="stylesheet" />
</head>
<body>
    <h2>PHP CRUD usando OOP con MySQLi en MVC</h2>
    <div>
        <ul class="menu-list">
            <li><a href="index.php">Estudiante</a></li>
            <li><a href="index.php?action=attendance">Asistencia</a></li>
        </ul>
    </div>