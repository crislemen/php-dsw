function traer() {
    const xhttp = new XMLHttpRequest();
    xhttp.open('GET','https://jsonplaceholder.typicode.com/users',true);

    xhttp.send();
    xhttp.onreadystatechange = function(){
        if (this.readyState ==4 && this.status == 200) {
            let datos = JSON.parse(this.responseText);
            let contenido = document.querySelector('#contenido');
            contenido.innerHTML = '';
            for(let item of datos){
                contenido.innerHTML += `
                <tr>
                    <td>${item.id}</td>
                    <td>${item.name}</td>
                    <td>${item.email}</td>
                    <td>${item.username}</td>
                </tr>
                `

            }
        }
    }
}